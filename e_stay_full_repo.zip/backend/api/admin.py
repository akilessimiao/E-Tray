from django.contrib import admin
from .models import Pousada, Reserva
admin.site.register(Pousada)
admin.site.register(Reserva)
