# Issues iniciais sugeridas

- Setup do ambiente (backend/frontend)
- Configuração CI/CD (GitHub Actions)
- Integração API <-> Frontend
- Personalização identidade visual (logo, cores)
- Deploy em staging (Render/Vercel)
- Implementar autenticação JWT
- Criar seed para popular pousadas via scrapper
- Dashboard administrativo
- Documentação e screenshots
