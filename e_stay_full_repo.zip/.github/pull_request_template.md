## 📋 Descrição
Descreva brevemente o que este PR faz e quais problemas resolve.

## 🧪 Testes realizados
- [ ] Testei o backend localmente
- [ ] Testei o frontend (build + integração)
- [ ] Verifiquei lint e CI

## 🔗 Issues relacionadas
Closes #

## ✅ Checklist
- [ ] Código revisado e limpo
- [ ] Documentação atualizada
- [ ] Testes passaram com sucesso
